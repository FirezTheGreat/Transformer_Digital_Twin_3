"""Project v3.0.2 (clean and DQ) onto the CPRI-suggested column names. Pure renaming/selection,
no value changes. Labels go to separate files (evaluation only, never runtime input).
Usage: python src/project_cpri_schema.py --data data --asset TX_250_MIX"""
import argparse, os
import pandas as pd

CPRI = {"meta_timestamp": "Timestamp", "meta_transformer_id": "Transformer ID",
        "x_voltage_ll_v": "Voltage (V)", "x_current_a": "Current (A)", "x_active_power_kw": "kW",
        "x_apparent_power_kva": "kVA", "x_power_factor": "PF", "x_frequency_hz": "Frequency (Hz)",
        "x_current_thd_pct": "THD (%)", "x_ambient_temp_c": "Ambient Temp (°C)", "x_oil_temp_c": "Oil Temp (°C)",
        "x_winding_temp_c": "Winding Temp (°C)", "x_vibration_mm_s_rms": "Vibration (mm/s)",
        "x_oil_level_pct": "Oil Level (%)", "x_bushing_temp_c": "Bushing Temp (°C)",
        "x_voltage_thd_pct": "THD Voltage (%)", "x_voltage_unbalance_pct": "Voltage Unbalance (%)",
        "x_current_unbalance_pct": "Current Unbalance (%)", "x_reactive_power_kvar": "kVAR",
        "x_neutral_current_a": "Neutral Current (A)"}

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--data", default="data"); ap.add_argument("--asset", default="TX_250_MIX")
    a = ap.parse_args()
    out = os.path.join(a.data, "cpri_schema"); os.makedirs(out, exist_ok=True)
    for src, tag in [("transformer_practical_schema_v3.0.2_30min.csv", "clean"),
                     ("transformer_practical_schema_v3.0.2_with_dq.csv", "with_dq")]:
        d = pd.read_csv(os.path.join(a.data, src))
        d = d[d.meta_transformer_id == a.asset].reset_index(drop=True)
        tel = d[list(CPRI)].rename(columns=CPRI); tel["Data Source"] = "SYNTHETIC_V3.0.2"
        tel.to_csv(os.path.join(out, f"{a.asset}_cpri_schema_{tag}.csv"), index=False, encoding="utf-8-sig")
        lab = d[[c for c in d.columns if c.startswith(("meta_", "y_"))]]
        lab.to_csv(os.path.join(out, f"{a.asset}_labels_{tag}.csv"), index=False)
    print("written", out)

if __name__ == "__main__":
    main()
