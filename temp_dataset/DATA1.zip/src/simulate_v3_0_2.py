"""
CPRI ONAN practical-schema synthetic transformer benchmark -- generator v3.0.2.

Authoritative implementation. Every equation used is in this file and documented in
DATASET_METHODOLOGY_V3.0.2.md; every parameter is in config/simulator_config_v3.0.2.json.

SYNTHETIC DATA. Not Tripura, CPRI, utility or field data. IEC 60076-7-*inspired*
thermal structure; NOT a standards-compliant implementation.

Usage:
    python src/simulate_v3_0_2.py --config config/simulator_config_v3.0.2.json --out data
Outputs:
    data/transformer_practical_schema_v3.0.2_30min.csv      clean scientific benchmark
    data/transformer_practical_schema_v3.0.2_with_dq.csv    data-quality stress benchmark
    data/v3.0.2_event_windows.csv                            every injected event
    data/v3.0.2_dq_defects.csv                               every injected DQ defect
    data/dataset_manifest.json
"""
import argparse, hashlib, json, os, platform
import numpy as np
import pandas as pd
from scipy.signal import lfilter

GENERATOR_VERSION = "3.0.2"
STREAMS = {"ambient": 0, "load": 1, "electrical_latent": 2, "electrical_noise": 3,
           "thermal_noise": 4, "condition_noise": 5, "event_schedule": 6,
           "fault_perturbation": 7, "dq": 8}
EVENT_ORDER = ["overload", "phase_imbalance", "cooling_degradation", "abnormal_internal_heating",
               "oil_sensor_bias", "oil_sensor_drift", "oil_sensor_stuck", "power_quality_disturbance",
               "oil_leak", "bushing_overheating", "vibration_anomaly"]
THERMAL_EVENTS = {"overload", "cooling_degradation", "abnormal_internal_heating"}
DT_MIN = 30.0

# ---------------------------------------------------------------- helpers
def rng_for(base_seed, asset_idx, stream):
    """Independent PCG64 stream: SeedSequence(base_seed, spawn_key=(asset_idx, stream_id))."""
    return np.random.Generator(np.random.PCG64(
        np.random.SeedSequence(base_seed, spawn_key=(asset_idx, STREAMS[stream]))))

def ar1(rng, n, phi, sd):
    """x[0] ~ N(0, sd^2/(1-phi^2)); x[k] = phi*x[k-1] + e[k], e ~ N(0, sd^2)."""
    e = rng.normal(0.0, sd, n)
    e[0] = e[0] / np.sqrt(1.0 - phi ** 2)
    return lfilter([1.0], [1.0, -phi], e)

def quant(x, q):
    return np.round(x / q) * q

def circ_gauss(h, mu, sig):
    d = np.abs(h - mu); d = np.minimum(d, 24.0 - d)
    return np.exp(-0.5 * (d / sig) ** 2)

def plateau(h, a, b, w=0.5):
    return 1.0 / (1.0 + np.exp(-(h - a) / w)) / (1.0 + np.exp(-(b - h) / w))

def profile_shape(kind, h):
    if kind == "residential":
        return 0.55 + 0.35 * circ_gauss(h, 7.5, 1.5) + 0.75 * circ_gauss(h, 20.0, 2.0)
    if kind == "commercial":
        return 0.40 + 0.75 * plateau(h, 9.0, 18.0)
    if kind == "rural":
        return 0.50 + 0.45 * circ_gauss(h, 5.5, 1.2) + 0.55 * circ_gauss(h, 19.5, 2.0)
    if kind == "mixed":
        return (0.50 + 0.30 * circ_gauss(h, 8.0, 1.5) + 0.30 * plateau(h, 10.0, 17.0)
                + 0.55 * circ_gauss(h, 20.0, 2.0))
    raise ValueError(kind)

def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()

# ---------------------------------------------------------------- event scheduling
def schedule_events(cfg, asset_idx, asset_id, ts, part_idx):
    """Per partition: one event of each of the 11 non-gap classes + `gaps_per_split` gaps.
    Classes are placed in EVENT_ORDER, then gaps. Start uniform over admissible starts,
    rejection on overlap (with guard) against already-placed events. Rows are latent-grid indices."""
    ev_cfg = cfg["events"]
    rs = rng_for(cfg["base_seed"], asset_idx, "event_schedule")
    rf = rng_for(cfg["base_seed"], asset_idx, "fault_perturbation")
    sev_names = list(ev_cfg["severity_probs"])
    sev_p = np.array([ev_cfg["severity_probs"][s] for s in sev_names])
    margin = int(ev_cfg["split_margin_h"] * 2)
    guard = int(ev_cfg["guard_h"] * 2)
    events = []
    for part in ["FIT", "CAL", "TEST"]:
        idx = np.flatnonzero(part_idx == part)
        lo, hi = idx[0] + margin, idx[-1] - margin
        occupied = []
        plan = [(c, 0) for c in EVENT_ORDER] + [("communication_gap", k) for k in range(ev_cfg["gaps_per_split"])]
        for cls, k in plan:
            cc = ev_cfg["classes"][cls]
            dur_h = rs.uniform(*cc["duration_h"])
            n_rows = max(1, int(round(dur_h * 2)))
            need = n_rows + (1 if cls == "communication_gap" else 0)   # gap needs its recovery row
            for _ in range(10000):
                s = int(rs.integers(lo, hi - need + 2))
                e = s + need - 1
                if all(e + guard < a or s - guard > b for a, b in occupied):
                    break
            else:
                raise RuntimeError(f"cannot place {cls} for {asset_id} {part}")
            occupied.append((s, e))
            if cls == "communication_gap":
                events.append(dict(asset=asset_id, cls=cls, part=part, start=s, end=s + n_rows - 1,
                                   recovery=s + n_rows, severity="none", mag=float("nan"),
                                   event_id=f"{asset_id}-{part}-communication_gap-{k + 1}"))
            else:
                sev = sev_names[int(rs.choice(len(sev_names), p=sev_p))]
                mag = float(rf.uniform(*cc["mag"][sev]))
                events.append(dict(asset=asset_id, cls=cls, part=part, start=s, end=e, recovery=-1,
                                   severity=sev, mag=mag, event_id=f"{asset_id}-{part}-{cls}"))
    return events

# ---------------------------------------------------------------- one asset
def simulate_asset(cfg, asset_idx, a, ts):
    N = len(ts)
    bs = cfg["base_seed"]
    h = np.asarray(ts.hour + ts.minute / 60.0, dtype=float)
    doy = np.asarray(ts.dayofyear, dtype=float) - 1 + h / 24.0 + 1.0          # 1-based fractional day of year
    t_h = np.arange(N) * DT_MIN / 60.0                            # hours since start
    weekend = np.asarray(ts.dayofweek) >= 5
    part = np.empty(N, dtype=object)
    for p, (s, e) in cfg["partitions"].items():
        part[(ts >= pd.Timestamp(s)) & (ts < pd.Timestamp(e))] = p

    events = schedule_events(cfg, asset_idx, a["id"], ts, part)

    # event drive arrays on the latent grid
    ovl_m = np.zeros(N); ovl = np.zeros(N, bool)
    pi_m = np.zeros(N); c_cool = np.zeros(N); q_heat = np.zeros(N)
    bias = np.zeros(N); stuck = np.zeros(N, bool); pqd_s = np.zeros(N)
    leak = np.zeros(N); bush_m = np.zeros(N); bush_ramp = np.zeros(N); vib_a = np.zeros(N)
    gap_del = np.zeros(N, bool)
    for ev in events:
        s, e, m = ev["start"], ev["end"], ev["mag"]
        sl = slice(s, e + 1)
        el_h = (np.arange(s, e + 1) - s) * DT_MIN / 60.0                       # hours since event start
        frac = el_h / max(el_h[-1], 1e-9) if e > s else np.ones(1)
        c = ev["cls"]
        if c == "overload": ovl[sl] = True; ovl_m[sl] = m
        elif c == "phase_imbalance": pi_m[sl] = m
        elif c == "cooling_degradation": c_cool[sl] = m
        elif c == "abnormal_internal_heating": q_heat[sl] = m
        elif c == "oil_sensor_bias": bias[sl] += m
        elif c == "oil_sensor_drift": bias[sl] += m * frac
        elif c == "oil_sensor_stuck": stuck[sl] = True
        elif c == "power_quality_disturbance": pqd_s[sl] = m
        elif c == "oil_leak": leak[sl] = m * (el_h + DT_MIN / 60.0) / 24.0   # % lost so far; topped up at end
        elif c == "bushing_overheating":
            bush_m[sl] = m; bush_ramp[sl] = np.minimum(1.0, (el_h + DT_MIN / 60.0) / cfg["events"]["bushing_ramp_h"])
        elif c == "vibration_anomaly": vib_a[sl] = m
        elif c == "communication_gap": gap_del[sl] = True

    # ---------------- ambient
    A = cfg["ambient"]; ra = rng_for(bs, asset_idx, "ambient")
    n_days = int(np.ceil(t_h[-1] / 24.0)) + 2
    syn_nodes = ar1(ra, n_days, A["synoptic_phi"], A["synoptic_sd"])
    synoptic = np.interp(t_h, np.arange(n_days) * 24.0 + 12.0, syn_nodes)
    micro = ar1(ra, N, A["micro_phi"], A["micro_sd"])
    offset = A["asset_offset_step"] * (asset_idx - 3.5)
    T_amb = (A["mean"] + A["seasonal_amp"] * np.sin(2 * np.pi * (doy - A["seasonal_phase_day"]) / 365.25)
             + A["diurnal_amp"] * np.sin(2 * np.pi * (h - A["diurnal_phase_h"]) / 24.0)
             + synoptic + micro + offset)

    # ---------------- load (per unit of rating)
    L = cfg["load"]; rl = rng_for(bs, asset_idx, "load")
    hh = np.arange(48) / 2.0
    norm = profile_shape(a["profile"], hh).mean()
    prof = profile_shape(a["profile"], h) / norm * np.where(weekend, L["weekend_factor"][a["profile"]], 1.0)
    d_nodes = ar1(rl, n_days, L["daily_phi"], L["daily_lognormal_sd"] * np.sqrt(1 - L["daily_phi"] ** 2))
    daily = np.exp(np.interp(t_h, np.arange(n_days) * 24.0 + 12.0, d_nodes))
    annual = 1.0 + L["annual_amp"] * np.sin(2 * np.pi * (doy - L["annual_phase_day"]) / 365.25)
    fast = ar1(rl, N, L["fast_phi"], L["fast_sd"])
    K = np.clip(a["base_load_pu"] * prof * daily * annual * (1.0 + fast), *L["clip"])
    f0, f1 = cfg["events"]["overload_floor"]
    K = np.where(ovl, np.maximum(K * (1 + ovl_m), f0 + f1 * ovl_m), K)
    K = np.clip(K, *L["clip"])

    # ---------------- electrical latent
    E = cfg["electrical"]; re_ = rng_for(bs, asset_idx, "electrical_latent")
    share_bias = 1.0 / 3.0 + re_.normal(0, E["phase_share_bias_sd"], 3)
    share_bias /= share_bias.sum()
    share = share_bias[None, :] + np.column_stack([ar1(re_, N, E["phase_share_phi"], E["phase_share_sd"]) for _ in range(3)])
    share[:, 0] += pi_m; share[:, 1] -= pi_m / 2; share[:, 2] -= pi_m / 2
    share = np.clip(share, 0.05, None); share /= share.sum(1, keepdims=True)
    V0 = cfg["nominal"]["v_ll"] / np.sqrt(3)
    weekly = 1.0 + E["weekly_v_amp"] * np.sin(2 * np.pi * t_h / 168.0)
    pv = np.column_stack([ar1(re_, N, E["phase_v_phi"], E["phase_v_sd"]) for _ in range(3)])
    pq_v = cfg["events"]["pqd"]["v_phase_per_s"] * pqd_s[:, None] * np.array([1.0, -0.5, -0.5])[None, :]
    K_ph = 3.0 * share * K[:, None]
    V_ph = V0 * weekly[:, None] * (1 + pv) * (1 - E["v_drop_per_pu"] * K_ph) * (1 + pq_v)
    theta = np.deg2rad(np.array([0.0, -120.0, 120.0])[None, :] + re_.normal(0, E["angle_jitter_deg_sd"], (N, 3)))
    pf_c = np.clip(E["pf_base"] + E["pf_load_slope"] * (K - 0.5) + ar1(re_, N, E["pf_phi"], E["pf_sd"]), *E["pf_clip"])
    pf_ph = np.clip(pf_c[:, None] + re_.normal(0, E["pf_phase_sd"], 3)[None, :], *E["pf_clip"])
    S_ph = share * K[:, None] * a["rating_kva"]
    I_ph = S_ph * 1000.0 / V_ph
    phi = np.arccos(pf_ph)
    P_lat = (S_ph * pf_ph).sum(1); Q_lat = (S_ph * np.sin(phi)).sum(1)
    S_lat = np.hypot(P_lat, Q_lat)
    I_N = np.abs((I_ph * np.exp(1j * (theta - phi))).sum(1))
    Vc = V_ph * np.exp(1j * theta)
    V_LL = (np.abs(Vc[:, 0] - Vc[:, 1]) + np.abs(Vc[:, 1] - Vc[:, 2]) + np.abs(Vc[:, 2] - Vc[:, 0])) / 3.0
    k = np.arange(N)
    pq = cfg["events"]["pqd"]
    freq = (cfg["nominal"]["frequency_hz"] + ar1(re_, N, E["freq_phi"], E["freq_sd"])
            + E["freq_diurnal_amp"] * np.sin(2 * np.pi * (h - 14.0) / 24.0)
            + pq["freq_per_s"] * pqd_s * np.sin(np.pi * k / 2.0))
    thd_v = np.clip(E["thd_v_base"] + E["thd_v_load"] * K + ar1(re_, N, E["thd_v_phi"], E["thd_v_sd"]) + pq["thd_v_per_s"] * pqd_s, 0.2, None)
    thd_i = np.clip(E["thd_i_base"] + E["thd_i_load"] * K + ar1(re_, N, E["thd_i_phi"], E["thd_i_sd"]) + pq["thd_i_per_s"] * pqd_s, 0.2, None)

    # ---------------- electrical observation (truncated joint noise: P_obs <= S_obs, |Q_obs| <= S_obs)
    rn = rng_for(bs, asset_idx, "electrical_noise"); nf = E["noise_frac"]
    bV = rn.normal(0, E["bias_frac_sd"], 3); bI = rn.normal(0, E["bias_frac_sd"], 3)
    bP, bQ, bS = rn.normal(0, E["bias_frac_sd"], 3)
    V_obs = V_ph * (1 + bV[None, :] + rn.normal(0, nf["V"], (N, 3)))
    I_obs = I_ph * (1 + bI[None, :] + rn.normal(0, nf["I"], (N, 3)))
    eP, eQ, eS = rn.normal(0, nf["P"], N), rn.normal(0, nf["Q"], N), rn.normal(0, nf["S"], N)
    def obs_pqs():
        return P_lat * (1 + bP + eP), Q_lat * (1 + bQ + eQ), S_lat * (1 + bS + eS)
    P_obs, Q_obs, S_obs = obs_pqs()
    redraws = 0
    for _ in range(100):
        bad = (P_obs > S_obs) | (np.abs(Q_obs) > S_obs)
        if not bad.any(): break
        nb = int(bad.sum()); redraws += nb
        eP[bad] = rn.normal(0, nf["P"], nb); eQ[bad] = rn.normal(0, nf["Q"], nb); eS[bad] = rn.normal(0, nf["S"], nb)
        P_obs, Q_obs, S_obs = obs_pqs()
    assert not ((P_obs > S_obs) | (np.abs(Q_obs) > S_obs)).any()
    PF_obs = np.clip(P_lat / S_lat + rn.normal(0, E["pf_obs_sd"], N), 0.0, 0.999)
    f_obs = freq + rn.normal(0, E["freq_obs_sd"], N)
    thdv_obs = np.clip(thd_v + rn.normal(0, E["thd_obs_sd"], N), 0, None)
    thdi_obs = np.clip(thd_i + rn.normal(0, E["thd_obs_sd"], N), 0, None)
    VLL_obs = V_LL * (1 + rn.normal(0, E["vll_obs_frac"], N))
    IN_obs = np.clip(I_N * (1 + rn.normal(0, E["neutral_obs_frac"], N)), 0, None)

    # ---------------- thermal latent (exact first-order update, IEC 60076-7-inspired)
    T = cfg["thermal"]; y = T["winding_exponent_y"]
    l0, l1, l2 = T["tau_oil_load_terms"]; w0, w1, w2 = T["tau_wdg_terms"]
    dTo_u = a["dT_oil_r"] * ((1 + a["R"] * K ** 2) / (1 + a["R"])) ** a["n"] * (1 + c_cool) + q_heat
    tau_o = np.clip(a["tau_oil_r"] * (l0 + l1 / (l2 + K)) * (1 + T["tau_oil_amb_coef"] * (T["tau_oil_amb_ref"] - T_amb))
                    * (1 + T["tau_oil_cool_coef"] * c_cool), T["tau_oil_clip"][0] * a["tau_oil_r"], T["tau_oil_clip"][1] * a["tau_oil_r"])
    dTw_u = a["dT_wdg_r"] * np.maximum(K, T["K_floor_wdg"]) ** y
    tau_w = a["tau_wdg_r"] * (w0 + w1 / (w2 + K))
    al_o = 1 - np.exp(-DT_MIN / tau_o); al_w = 1 - np.exp(-DT_MIN / tau_w)
    dTo = np.empty(N); dTw = np.empty(N)
    so, sw = dTo_u[0], dTw_u[0]                       # start at steady state
    for i in range(N):
        if i:
            so += al_o[i] * (dTo_u[i] - so); sw += al_w[i] * (dTw_u[i] - sw)
        dTo[i] = so; dTw[i] = sw
    T_oil = T_amb + dTo; T_wdg = T_oil + dTw

    # ---------------- condition channels latent (empirical models)
    B = cfg["bushing"]
    targ = T_amb + B["offset"] + B["oil_rise_coef"] * dTo + B["load2_coef"] * K ** 2 + bush_m * (0.4 + 0.6 * K ** 2) * bush_ramp
    ab = 1 - np.exp(-DT_MIN / B["tau_min"]); T_b = np.empty(N); sb = targ[0]
    for i in range(N):
        if i: sb += ab * (targ[i] - sb)
        T_b[i] = sb
    OL = cfg["oil_level"]
    lvl = OL["L0"] + OL["expansion_pct_per_degC"] * (T_oil - OL["T_ref"]) - leak
    VB = cfg["vibration"]
    vib = (VB["v0"] + VB["load2_coef"] * K ** 2 + VB["volt2_coef"] * (V_ph.mean(1) / V0) ** 2
           + vib_a * (1 + cfg["events"]["vibration_load2_coef"] * K ** 2))

    # ---------------- thermal / condition observation
    rt = rng_for(bs, asset_idx, "thermal_noise"); TN = T["obs_noise_sd"]; q = T["obs_quantum"]
    amb_obs = quant(T_amb + rt.normal(0, A["obs_noise_sd"], N), A["obs_quantum"])
    oil_obs = quant(T_oil + rt.normal(0, TN["oil"], N) + bias, q)
    for ev in events:                                  # stuck: hold last observed value before the event
        if ev["cls"] == "oil_sensor_stuck":
            oil_obs[ev["start"]:ev["end"] + 1] = oil_obs[ev["start"] - 1]
    wdg_obs = quant(T_wdg + rt.normal(0, TN["winding"], N), q)
    rc = rng_for(bs, asset_idx, "condition_noise")
    bush_obs = quant(T_b + rc.normal(0, B["obs_noise_sd"], N), B["obs_quantum"])
    lvl_obs = np.clip(quant(lvl + rc.normal(0, OL["obs_noise_sd"], N), OL["obs_quantum"]), *OL["clip"])
    vib_obs = vib * np.exp(rc.normal(0, VB["obs_lognormal_sd"], N))

    # ---------------- assemble observed rows (communication-gap rows removed)
    def vu(Vm):
        m = Vm.mean(1); return np.abs(Vm - m[:, None]).max(1) / m * 100.0
    df = pd.DataFrame({
        "meta_transformer_id": a["id"], "ts": ts, "meta_partition": part,
        "x_rating_kva": float(a["rating_kva"]),
        "x_voltage_ll_v": VLL_obs,
        "x_v_l1n_v": V_obs[:, 0], "x_v_l2n_v": V_obs[:, 1], "x_v_l3n_v": V_obs[:, 2],
        "x_voltage_unbalance_pct": vu(V_obs),
        "x_current_a": I_obs.mean(1),
        "x_i_l1_a": I_obs[:, 0], "x_i_l2_a": I_obs[:, 1], "x_i_l3_a": I_obs[:, 2],
        "x_current_unbalance_pct": vu(I_obs),
        "x_neutral_current_a": IN_obs,
        "x_active_power_kw": P_obs, "x_reactive_power_kvar": Q_obs, "x_apparent_power_kva": S_obs,
        "x_power_factor": PF_obs, "x_frequency_hz": f_obs,
        "x_voltage_thd_pct": thdv_obs, "x_current_thd_pct": thdi_obs,
        "x_ambient_temp_c": amb_obs, "x_oil_temp_c": oil_obs, "x_winding_temp_c": wdg_obs,
        "x_bushing_temp_c": bush_obs, "x_vibration_mm_s_rms": vib_obs, "x_oil_level_pct": lvl_obs,
    })
    df["x_load_pu"] = df.x_apparent_power_kva / df.x_rating_kva

    # labels on the latent grid
    ftype = np.full(N, "normal", dtype=object); fdom = np.full(N, "normal", dtype=object)
    fsev = np.full(N, "none", dtype=object); fid = np.full(N, "none", dtype=object)
    inelig = np.zeros(N, bool)
    taur_rows = int(round(cfg["fit_eligibility"]["thermal_recovery_tau_multiple"] * a["tau_oil_r"] / DT_MIN))
    warm_rows = int(round(cfg["fit_eligibility"]["post_gap_warmup_h"] * 60 / DT_MIN))
    for ev in events:
        cc = cfg["events"]["classes"][ev["cls"]]
        if ev["cls"] == "communication_gap":
            r = ev["recovery"]
            ftype[r], fdom[r], fsev[r], fid[r] = ev["cls"], cc["domain"], "none", ev["event_id"]
            inelig[ev["start"]:r + 1 + warm_rows] = True
        else:
            sl = slice(ev["start"], ev["end"] + 1)
            ftype[sl], fdom[sl], fsev[sl], fid[sl] = ev["cls"], cc["domain"], ev["severity"], ev["event_id"]
            inelig[sl] = True
            if ev["cls"] in THERMAL_EVENTS:
                inelig[ev["end"] + 1:ev["end"] + 1 + taur_rows] = True
    df["y_fault_type"], df["y_fault_domain"], df["y_severity"], df["y_event_id"] = ftype, fdom, fsev, fid
    df["_inelig"] = inelig
    df = df[~gap_del].reset_index(drop=True)

    # ---------------- time-based engineered features (no fabricated rows)
    s_ts = df.set_index("ts")
    lag = s_ts.x_load_pu.reindex(df.ts - pd.Timedelta("1h")).to_numpy()
    oil_lag = s_ts.x_oil_temp_c.reindex(df.ts - pd.Timedelta("1h")).to_numpy()
    df["x_oil_rise_over_ambient_c"] = df.x_oil_temp_c - df.x_ambient_temp_c
    df["x_winding_rise_over_ambient_c"] = df.x_winding_temp_c - df.x_ambient_temp_c
    df["x_load_pu_lag_1h"] = lag
    df["x_load_pu_rolling_6h"] = s_ts.x_load_pu.rolling("6h", closed="right").mean().to_numpy()
    df["x_oil_temp_rate_c_per_h"] = (df.x_oil_temp_c.to_numpy() - oil_lag) / 1.0
    df["x_minutes_since_previous"] = df.ts.diff().dt.total_seconds() / 60.0
    hr = df.ts.dt.hour + df.ts.dt.minute / 60.0
    dy = df.ts.dt.dayofyear
    df["x_hour_sin"], df["x_hour_cos"] = np.sin(2 * np.pi * hr / 24), np.cos(2 * np.pi * hr / 24)
    df["x_dayofyear_sin"], df["x_dayofyear_cos"] = np.sin(2 * np.pi * dy / 365.25), np.cos(2 * np.pi * dy / 365.25)

    AL = cfg["alerts"]
    df["y_anomaly"] = (df.y_fault_type != "normal").astype(int)
    df["y_thermal_alert_level"] = np.select(
        [df.x_winding_temp_c >= AL["critical"], df.x_winding_temp_c >= AL["warning"], df.x_winding_temp_c >= AL["watch"]],
        ["critical", "warning", "watch"], "normal")
    df["y_wti_alarm"] = (df.x_winding_temp_c >= AL["wti_alarm"]).astype(int)
    req = ["x_ambient_temp_c", "x_oil_temp_c", "x_winding_temp_c", "x_load_pu", "x_apparent_power_kva"]
    valid = np.isfinite(df[req].to_numpy()).all(1)
    df["y_fit_eligible"] = ((~df._inelig) & valid).astype(int)
    df = df.drop(columns="_inelig")

    ev_rows = []
    for ev in events:
        r = dict(ev)
        r["start_ts"] = ts[ev["start"]].isoformat(); r["end_ts"] = ts[ev["end"]].isoformat()
        r["recovery_ts"] = ts[ev["recovery"]].isoformat() if ev["recovery"] >= 0 else ""
        r["n_rows"] = ev["end"] - ev["start"] + 1
        ev_rows.append(r)
    stats = {"pqs_noise_redraws": redraws}
    return df, ev_rows, stats

# ---------------------------------------------------------------- data-quality benchmark
RAW_COLS = ["x_rating_kva", "x_voltage_ll_v", "x_v_l1n_v", "x_v_l2n_v", "x_v_l3n_v", "x_voltage_unbalance_pct",
            "x_current_a", "x_i_l1_a", "x_i_l2_a", "x_i_l3_a", "x_current_unbalance_pct", "x_neutral_current_a",
            "x_active_power_kw", "x_reactive_power_kvar", "x_apparent_power_kva", "x_power_factor", "x_frequency_hz",
            "x_voltage_thd_pct", "x_current_thd_pct", "x_ambient_temp_c", "x_oil_temp_c", "x_winding_temp_c",
            "x_bushing_temp_c", "x_vibration_mm_s_rms", "x_oil_level_pct", "x_load_pu"]
ELEC_ZERO = ["x_voltage_ll_v", "x_v_l1n_v", "x_v_l2n_v", "x_v_l3n_v", "x_current_a", "x_i_l1_a", "x_i_l2_a", "x_i_l3_a",
             "x_neutral_current_a", "x_active_power_kw", "x_reactive_power_kvar", "x_apparent_power_kva", "x_load_pu"]
ELEC_NAN = ["x_power_factor", "x_frequency_hz", "x_voltage_thd_pct", "x_current_thd_pct",
            "x_voltage_unbalance_pct", "x_current_unbalance_pct"]

def build_dq(cfg, clean):
    """Raw-telemetry stress copy. Engineered features are NOT carried (consumers must recompute after
    their own cleaning). Defects placed only on normal rows away from gaps/events (>=6 h)."""
    D = cfg["dq"]
    keep = ["meta_transformer_id", "meta_timestamp", "meta_partition"] + RAW_COLS + \
           ["y_anomaly", "y_fault_type", "y_fault_domain", "y_severity", "y_event_id"]
    parts, log = [], []
    for ai, aid in enumerate([a["id"] for a in cfg["assets"]]):
        rd = rng_for(cfg["base_seed"], ai, "dq")
        d = clean[clean.meta_transformer_id == aid][keep].reset_index(drop=True).copy()
        d["y_dq_defect"] = "none"; d["y_dq_id"] = "none"
        okmask = (clean[clean.meta_transformer_id == aid].y_anomaly.to_numpy() == 0)
        okmask &= (clean[clean.meta_transformer_id == aid].x_minutes_since_previous.fillna(30).to_numpy() == 30)
        ok = pd.Series(okmask).rolling(25, center=True, min_periods=1).min().to_numpy().astype(bool)
        used = np.zeros(len(d), bool)
        def place(L):
            for _ in range(10000):
                s = int(rd.integers(30, len(d) - L - 30))
                if ok[s:s + L].all() and not used[max(0, s - 24):s + L + 24].any():
                    used[s:s + L] = True; return s
            raise RuntimeError("dq placement failed")
        def mark(s, L, kind, n):
            did = f"{aid}-DQ-{kind}-{n}"
            d.loc[s:s + L - 1, ["y_dq_defect", "y_dq_id"]] = [kind, did]
            log.append(dict(asset=aid, dq_id=did, defect=kind, start_ts=d.meta_timestamp[s],
                            end_ts=d.meta_timestamp[s + L - 1], n_rows=L))
        P = D["per_asset"]
        for n in range(P["outage"]):
            L = int(round(rd.uniform(*D["outage_h"]) * 2)); s = place(L)
            d.loc[s:s + L - 1, ELEC_ZERO] = 0.0; d.loc[s:s + L - 1, ELEC_NAN] = np.nan; mark(s, L, "SUPPLY_OUTAGE", n + 1)
        for n in range(P["missing_block"]):
            L = int(rd.integers(D["missing_rows"][0], D["missing_rows"][1] + 1)); s = place(L)
            cols = list(rd.choice(RAW_COLS[1:], size=int(rd.integers(1, 4)), replace=False))
            d.loc[s:s + L - 1, cols] = np.nan; mark(s, L, "MISSING_VALUES", n + 1)
        for n in range(P["unit_error_kw"]):
            L = int(round(rd.uniform(*D["unit_error_h"]) * 2)); s = place(L)
            d.loc[s:s + L - 1, "x_active_power_kw"] *= 1000.0; mark(s, L, "UNIT_ERROR_KW_AS_W", n + 1)
        for n in range(P["spike_oil"]):
            s = place(1); d.loc[s, "x_oil_temp_c"] = 250.0 if n % 2 == 0 else -40.0; mark(s, 1, "SPIKE_OIL_TEMP", n + 1)
        to_delete, dup_rows, swaps, tz_blocks = [], [], [], []
        for n in range(P["dq_gap"]):
            L = int(round(rd.uniform(*D["dq_gap_h"]) * 2)); s = place(L); mark(s, L, "DQ_GAP_ROWS_MISSING", n + 1)
            to_delete += list(range(s, s + L))
        for n in range(P["exact_duplicate"]):
            s = place(1); mark(s, 1, "EXACT_DUPLICATE", n + 1); dup_rows.append((s, False))
        for n in range(P["conflicting_duplicate"]):
            s = place(1); mark(s, 1, "CONFLICTING_DUPLICATE", n + 1); dup_rows.append((s, True))
        for n in range(P["out_of_order"]):
            s = place(2); mark(s, 2, "OUT_OF_ORDER", n + 1); swaps.append(s)
        for n in range(P["timezone_shift"]):
            L = int(rd.integers(D["timezone_shift_rows"][0], D["timezone_shift_rows"][1] + 1)); s = place(L)
            mark(s, L, "TIMESTAMP_WRITTEN_AS_UTC", n + 1); tz_blocks.append((s, L))
        for s, L in tz_blocks:   # local clock time written 5h30 early with +05:30 suffix
            t = pd.to_datetime(d.loc[s:s + L - 1, "meta_timestamp"]) - pd.Timedelta("5h30min")
            d.loc[s:s + L - 1, "meta_timestamp"] = t.map(lambda x: x.isoformat()).to_numpy()
        order = list(range(len(d)))
        for s in swaps: order[s], order[s + 1] = order[s + 1], order[s]
        out_rows = []
        dups = {s: c for s, c in dup_rows}
        delset = set(to_delete)
        for i in order:
            if i in delset: continue
            out_rows.append(d.iloc[i])
            if i in dups:
                r = d.iloc[i].copy()
                if dups[i]:
                    r["x_oil_temp_c"] = r["x_oil_temp_c"] + 3.0; r["x_apparent_power_kva"] = r["x_apparent_power_kva"] * 1.2
                out_rows.append(r)
        parts.append(pd.DataFrame(out_rows))
    return pd.concat(parts, ignore_index=True), pd.DataFrame(log)

# ---------------------------------------------------------------- main
COL_ORDER = ["meta_transformer_id", "meta_timestamp", "meta_partition", "x_rating_kva", "x_voltage_ll_v",
             "x_v_l1n_v", "x_v_l2n_v", "x_v_l3n_v", "x_voltage_unbalance_pct", "x_current_a", "x_i_l1_a", "x_i_l2_a",
             "x_i_l3_a", "x_current_unbalance_pct", "x_neutral_current_a", "x_active_power_kw", "x_reactive_power_kvar",
             "x_apparent_power_kva", "x_power_factor", "x_frequency_hz", "x_voltage_thd_pct", "x_current_thd_pct",
             "x_ambient_temp_c", "x_oil_temp_c", "x_winding_temp_c", "x_bushing_temp_c", "x_vibration_mm_s_rms",
             "x_oil_level_pct", "x_oil_rise_over_ambient_c", "x_winding_rise_over_ambient_c", "x_load_pu",
             "x_load_pu_lag_1h", "x_load_pu_rolling_6h", "x_oil_temp_rate_c_per_h", "x_minutes_since_previous",
             "x_hour_sin", "x_hour_cos", "x_dayofyear_sin", "x_dayofyear_cos", "y_anomaly", "y_fault_type",
             "y_fault_domain", "y_severity", "y_event_id", "y_thermal_alert_level", "y_wti_alarm", "y_fit_eligible"]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config/simulator_config_v3.0.2.json")
    ap.add_argument("--out", default="data")
    a = ap.parse_args()
    cfg = json.load(open(a.config))
    os.makedirs(a.out, exist_ok=True)
    ts = pd.date_range(pd.Timestamp(cfg["start"]), pd.Timestamp(cfg["end_exclusive"]),
                       freq=f"{cfg['cadence_minutes']}min", inclusive="left")
    frames, evs, stats = [], [], {}
    for i, asset in enumerate(cfg["assets"]):
        df, ev, st = simulate_asset(cfg, i, asset, ts)
        frames.append(df); evs += ev; stats[asset["id"]] = st
    clean = pd.concat(frames, ignore_index=True)
    clean["meta_timestamp"] = clean.ts.map(lambda x: x.isoformat())
    clean = clean[COL_ORDER]
    float_cols = clean.select_dtypes("float").columns
    clean[float_cols] = clean[float_cols].round(6)

    f_clean = os.path.join(a.out, "transformer_practical_schema_v3.0.2_30min.csv")
    clean.to_csv(f_clean, index=False)
    dq, dqlog = build_dq(cfg, clean)
    f_dq = os.path.join(a.out, "transformer_practical_schema_v3.0.2_with_dq.csv")
    dq.to_csv(f_dq, index=False)
    f_ev = os.path.join(a.out, "v3.0.2_event_windows.csv")
    pd.DataFrame(evs)[["asset", "event_id", "cls", "part", "severity", "mag", "start_ts", "end_ts",
                       "recovery_ts", "n_rows"]].rename(columns={"cls": "fault_type", "part": "partition"}).to_csv(f_ev, index=False)
    f_dql = os.path.join(a.out, "v3.0.2_dq_defects.csv")
    dqlog.to_csv(f_dql, index=False)

    P = cfg["partitions"]
    manifest = {
        "dataset_id": cfg["dataset_id"], "version": "3.0.2", "generator_version": GENERATOR_VERSION,
        "synthetic": True, "timezone": cfg["timezone"], "cadence_minutes": cfg["cadence_minutes"],
        "assets": len(cfg["assets"]), "asset_ids": [x["id"] for x in cfg["assets"]],
        "ratings_kva": {x["id"]: x["rating_kva"] for x in cfg["assets"]},
        "seed": cfg["base_seed"],
        "rng": {"bit_generator": "PCG64", "rule": "SeedSequence(base_seed, spawn_key=(asset_index, stream_id))",
                "asset_index": "0-based position in config.assets", "streams": STREAMS},
        "fit_period": P["FIT"], "cal_period": P["CAL"], "test_period": P["TEST"],
        "partition_rule": "assigned by timestamp after a single continuous simulation per asset",
        "fault_classes": EVENT_ORDER + ["communication_gap"],
        "fault_labels_available": True, "labels_are_runtime_inputs": False,
        "label_columns": [c for c in COL_ORDER if c.startswith("y_")],
        "metadata_columns": [c for c in COL_ORDER if c.startswith("meta_")],
        "fit_eligibility_column": "y_fit_eligible",
        "ratings_verified": True,
        "ratings_note": "Ratings are the declared configuration of synthetic assets (verified to equal x_rating_kva in data); they are not nameplate data of real transformers.",
        "continuous_state_across_splits": True,
        "iec_compliance_claimed": False,
        "files": {os.path.basename(p): {"sha256": sha256(p)} for p in [f_clean, f_dq, f_ev, f_dql]},
        "rows": {"clean": int(len(clean)), "with_dq": int(len(dq)), "events": len(evs), "dq_defects": int(len(dqlog))},
        "generation_stats": stats,
        "environment": {"python": platform.python_version(), "numpy": np.__version__, "pandas": pd.__version__,
                        "scipy": __import__("scipy").__version__},
        "config_sha256": sha256(a.config),
    }
    with open(os.path.join(a.out, "dataset_manifest.json"), "w") as fh:
        json.dump(manifest, fh, indent=2)
    print(json.dumps(manifest["rows"]), json.dumps(stats))

if __name__ == "__main__":
    main()
