"""Automated checks for v3.0.2. Usage: python src/validate_v3_0_2.py --config ... --data data"""
import argparse, json, os
import numpy as np
import pandas as pd

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config/simulator_config_v3.0.2.json")
    ap.add_argument("--data", default="data")
    a = ap.parse_args()
    cfg = json.load(open(a.config))
    df = pd.read_csv(os.path.join(a.data, "transformer_practical_schema_v3.0.2_30min.csv"))
    dq = pd.read_csv(os.path.join(a.data, "transformer_practical_schema_v3.0.2_with_dq.csv"))
    ev = pd.read_csv(os.path.join(a.data, "v3.0.2_event_windows.csv"))
    df["ts"] = pd.to_datetime(df.meta_timestamp)
    R, M = {}, {}
    def chk(name, ok, metric=None):
        R[name] = bool(ok)
        if metric is not None: M[name] = metric

    chk("V01_columns_47", df.shape[1] == 48)  # +ts helper
    chk("V02_assets_8", df.meta_transformer_id.nunique() == 8)
    chk("V03_no_duplicate_asset_ts", not df.duplicated(["meta_transformer_id", "meta_timestamp"]).any())
    chk("V04_sorted_per_asset", all(g.ts.is_monotonic_increasing for _, g in df.groupby("meta_transformer_id")))
    expected_nan = {"x_load_pu_lag_1h", "x_oil_temp_rate_c_per_h", "x_minutes_since_previous"}
    nan_cols = set(df.columns[df.isna().any()])
    chk("V05_nan_only_in_time_features", nan_cols <= expected_nan, sorted(nan_cols))
    chk("V06_no_P_gt_S", not (df.x_active_power_kw > df.x_apparent_power_kva).any())
    chk("V07_no_absQ_gt_S", not (df.x_reactive_power_kvar.abs() > df.x_apparent_power_kva).any())
    resid = (df.x_apparent_power_kva - np.hypot(df.x_active_power_kw, df.x_reactive_power_kvar)).abs()
    chk("V08_S_not_algebraic", resid.median() > 0.1, {"median_abs_S_minus_PQ_kva": round(float(resid.median()), 3)})
    chk("V09_load_pu_def", np.allclose(df.x_load_pu, df.x_apparent_power_kva / df.x_rating_kva, atol=1e-5))
    chk("V10_current_mean", np.allclose(df.x_current_a, df[["x_i_l1_a", "x_i_l2_a", "x_i_l3_a"]].mean(axis=1), atol=1e-5))
    lv = np.select([df.x_winding_temp_c >= 120, df.x_winding_temp_c >= 105, df.x_winding_temp_c >= 95],
                   ["critical", "warning", "watch"], "normal")
    chk("V11_alert_rule", (lv == df.y_thermal_alert_level).all())
    chk("V12_wti_rule", ((df.x_winding_temp_c >= 105).astype(int) == df.y_wti_alarm).all())
    chk("V13_anomaly_rule", ((df.y_fault_type != "normal").astype(int) == df.y_anomaly).all())
    cov = df[df.y_anomaly == 1].groupby("y_fault_type").apply(lambda g: g.groupby(["meta_transformer_id", "meta_partition"]).ngroups)
    chk("V14_all_classes_every_asset_split", len(cov) == 12 and (cov == 24).all(), cov.to_dict())
    p_of = {}
    for p, (s, e) in cfg["partitions"].items():
        p_of[p] = (pd.Timestamp(s), pd.Timestamp(e))
    ev["s"], ev["e"] = pd.to_datetime(ev.start_ts), pd.to_datetime(ev.end_ts)
    margins = [min((r.s - p_of[r.partition][0]).total_seconds(), (p_of[r.partition][1] - r.e).total_seconds()) / 3600 for r in ev.itertuples()]
    chk("V15_events_inside_split_margin_48h", min(margins) >= 48 - 1e-9, {"min_margin_h": round(min(margins), 1)})
    part_ok = True
    for p, (s, e) in p_of.items():
        m = df.meta_partition == p
        part_ok &= bool(((df.ts[m] >= s) & (df.ts[m] < e)).all())
    chk("V16_partition_by_timestamp", part_ok)
    # time-based features
    ok_lag = ok_roll = ok_rate = True
    for _, g in df.groupby("meta_transformer_id"):
        s = g.set_index("ts")
        exp_lag = s.x_load_pu.reindex(g.ts - pd.Timedelta("1h")).to_numpy()
        ok_lag &= bool(np.allclose(g.x_load_pu_lag_1h, exp_lag, equal_nan=True, atol=1e-6))
        exp_roll = s.x_load_pu.rolling("6h").mean().to_numpy()
        ok_roll &= bool(np.allclose(g.x_load_pu_rolling_6h, exp_roll, atol=1e-5))
        exp_oil = s.x_oil_temp_c.reindex(g.ts - pd.Timedelta("1h")).to_numpy()
        ok_rate &= bool(np.allclose(g.x_oil_temp_rate_c_per_h, g.x_oil_temp_c - exp_oil, equal_nan=True, atol=1e-6))
    chk("V17_lag_1h_timestamp_exact", ok_lag)
    chk("V18_rolling_6h_time_window", ok_roll)
    chk("V19_oil_rate_exact_1h", ok_rate)
    gap_rec = df[df.y_fault_type == "communication_gap"]
    chk("V20_gap_recovery_rows_96", len(gap_rec) == 96 and (gap_rec.x_minutes_since_previous > 30).all())
    chk("V21_lag_nan_after_gap", gap_rec.x_load_pu_lag_1h.isna().all())
    # fit eligibility
    elig = df.y_fit_eligible == 1
    chk("V22_eligible_never_in_event", not (elig & (df.y_anomaly == 1)).any())
    rate = df.groupby("meta_partition").y_fit_eligible.mean().round(3).to_dict()
    chk("V23_eligible_share_reported", True, rate)
    # winding exponent: residual vs re-simulated K^1.6 state on eligible rows
    wres = {}
    for asset in cfg["assets"]:
        g = df[df.meta_transformer_id == asset["id"]]
        K = g.x_load_pu.to_numpy(); dt = g.x_minutes_since_previous.fillna(30).to_numpy()
        out = {}
        for y in (1.6, 3.2):
            u = asset["dT_wdg_r"] * np.maximum(K, 0.02) ** y
            al = 1 - np.exp(-dt / (asset["tau_wdg_r"] * (0.92 + 0.10 / (0.4 + K))))
            st = np.empty_like(u); st[0] = u[0]
            for i in range(1, len(u)): st[i] = st[i - 1] + al[i] * (u[i] - st[i - 1])
            r = (g.x_winding_temp_c - g.x_oil_temp_c).to_numpy() - st
            okr = ~g.y_fault_type.isin(["oil_sensor_bias", "oil_sensor_drift", "oil_sensor_stuck"]).to_numpy()
            out[y] = (round(float(r[okr].mean()), 2), round(float(r[okr].std()), 2))
        wres[asset["id"]] = out
    chk("V24_winding_exponent_1p6", all(abs(v[1.6][0]) < 0.3 and v[1.6][1] < v[3.2][1] for v in wres.values()),
        {k: {"1.6": v[1.6], "3.2": v[3.2]} for k, v in wres.items()})
    rng_t = {c: [float(df[c].min()), float(df[c].max())] for c in
             ["x_ambient_temp_c", "x_oil_temp_c", "x_winding_temp_c", "x_bushing_temp_c", "x_oil_level_pct", "x_vibration_mm_s_rms", "x_load_pu"]}
    chk("V25_temperature_ranges_plausible", rng_t["x_winding_temp_c"][1] < 160 and rng_t["x_oil_temp_c"][1] < 110, rng_t)
    chk("V26_dq_file_has_defects", (dq.y_dq_defect != "none").sum() > 0, dq.y_dq_defect.value_counts().to_dict())
    chk("V27_clean_has_no_dq_columns", "y_dq_defect" not in df.columns)
    M["anomaly_prevalence"] = df.groupby("meta_partition").y_anomaly.mean().round(4).to_dict()
    M["alert_counts"] = df.y_thermal_alert_level.value_counts().to_dict()
    n_over = df.x_load_pu > 1
    M["load_gt_1pu_rows"] = int(n_over.sum()); M["load_gt_1pu_labelled_overload_share"] = round(float((df[n_over].y_fault_type == "overload").mean()), 3)
    rep = {"overall": "PASS" if all(R.values()) else "FAIL", "passed": sum(R.values()), "total": len(R), "checks": R, "metrics": M}
    json.dump(rep, open(os.path.join(a.data, "validation_report_v3.0.2.json"), "w"), indent=2, default=str)
    print(json.dumps({"overall": rep["overall"], "passed": rep["passed"], "total": rep["total"],
                      "failed": [k for k, v in R.items() if not v]}, indent=1))
    print(json.dumps(M, indent=1, default=str)[:3000])

if __name__ == "__main__":
    main()
